<?php
// put this in directory called /ajax.googleapis.com/

require('../disallow/index.php');
