<?php

Class!

is_robots()
    add_filter('robots_txt', $this->add_disallow, 2, 1);

is_admin()
    trap type: fail2ban/.htaccess/nginx.conf/CloudFlare API/call itsec
    $rt_fail2ban_count = 6
    $rt_allow_url = 'allow' ?randomize
    $rt_allow_meta_url = 'allow-meta' ?randomize
    $rt_disallow = 'disallow' ?randomize
    $rt_relative_url = '//'. 'ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js'
    $rt_crawl_delay_on Y/N
    $rt_crawl_delay = 10
    -> options-general.php fieldset

!is_admin()
    add_rewrite_rule('^allow/?$','index.php?sec_nofollow=allow','bottom');
    add_rewrite_rule('^allow-meta/?$','index.php?sec_nofollow=allow_meta','bottom');
    add_rewrite_rule('^/ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js$','index.php?sec_nofollow=rel_url','bottom');
    add_rewrite_rule('^disallow/?$','index.php?sec_nofollow=disallow','bottom');
// different traps: rel nofollow, robots meta, robots.txt, realtive protocol

    add_rewrite_tag('sec_nofollow', '([a-z_]+)');

add_disallow()
    //'User-agent: *'. PHPEOL .
    'Crawl-delay: 10'.'Disallow: /disallow/'. PHPEOL .'Allow: /allow/'

trap/fail2ban
    for ($i = 1; $i <= $rt_ban_count; $i++) {
        error_log('File does not exist: robot_nofollow_trap');
    }
    die;

which action to hook for queries?

inject allow link in footer? inline display:none?
